norm_data <- round(rnorm(100))
print(norm_data)
count_table <- table(norm_data)
print(count_table)
