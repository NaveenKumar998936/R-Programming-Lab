data <- read.csv("exam_data.csv")
print(data)
