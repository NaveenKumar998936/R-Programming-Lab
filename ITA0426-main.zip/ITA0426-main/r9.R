plot(0, 0, type="n",
     xlim=c(0, 10),
     ylim=c(0, 20),
     xlab="X Axis",
     ylab="Y Axis",
     main="Empty Plot")
